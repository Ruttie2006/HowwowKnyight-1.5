# HowwowKnyight-1.5
HowwowKnyight - UwU Mod

De HowwowKnyight mod twanswates aww of de text in Howwow Knyight into de much supewiow UwU wanguage, incwuding menyus, usew intewface and in-game diawogues! >w<

Uses de Modding API, instaww by pwacing the DWW fiwe into the Mods fowdew.

By Henpemaz aka Henrique Maziero. (And Ruttie#3005!)

Built on [this api](https://github.com/hk-modding/api/actions/runs/998921662).
